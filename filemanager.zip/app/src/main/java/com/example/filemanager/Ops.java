package com.example.filemanager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Операции с файлами. Вызывать только из фонового потока. */
final class Ops {

    interface Progress {
        void update(String message);
        boolean cancelled();
    }

    static final class Cancelled extends IOException {
        Cancelled() { super("Отменено"); }
    }

    private Ops() { }

    private static void check(Progress p) throws Cancelled {
        if (p != null && p.cancelled()) throw new Cancelled();
    }

    /** Свободное имя: если файл есть, добавляется « (1)», « (2)» и т.д. */
    static File uniqueName(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        for (int i = 1; i < 1000; i++) {
            File c = new File(dir, base + " (" + i + ")" + ext);
            if (!c.exists()) return c;
        }
        return new File(dir, base + "_" + System.currentTimeMillis() + ext);
    }

    static boolean isInside(File parent, File child) {
        try {
            String p = parent.getCanonicalPath();
            String c = child.getCanonicalPath();
            return c.equals(p) || c.startsWith(p.endsWith("/") ? p : p + "/");
        } catch (IOException e) {
            return false;
        }
    }

    // ------------------------------------------------------------ копирование

    /** Копирует файл или папку внутрь dstDir (имя при совпадении меняется). */
    static void copy(File src, File dstDir, Progress p) throws IOException {
        File dst = uniqueName(dstDir, src.getName());
        copyTree(src, dst, p);
    }

    private static void copyTree(File src, File dst, Progress p) throws IOException {
        check(p);
        if (src.isDirectory()) {
            if (!dst.mkdirs() && !dst.isDirectory()) {
                throw new IOException("Не удалось создать папку " + dst.getName());
            }
            File[] ch = src.listFiles();
            if (ch != null) {
                for (File c : ch) copyTree(c, new File(dst, c.getName()), p);
            }
            dst.setLastModified(src.lastModified());
        } else {
            copyFile(src, dst, p);
        }
    }

    private static void copyFile(File src, File dst, Progress p) throws IOException {
        if (p != null) p.update(src.getName());
        InputStream in = new FileInputStream(src);
        OutputStream out = null;
        boolean ok = false;
        try {
            out = new FileOutputStream(dst);
            byte[] buf = new byte[64 * 1024];
            long total = src.length();
            long done = 0;
            long lastReport = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (p != null) {
                    if (p.cancelled()) throw new Cancelled();
                    if (done - lastReport > 4L * 1024 * 1024 && total > 0) {
                        lastReport = done;
                        p.update(src.getName() + "  —  " + (done * 100 / total) + "%");
                    }
                }
            }
            ok = true;
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            if (out != null) {
                try { out.close(); } catch (IOException ignored) { }
            }
            if (!ok) dst.delete(); // недокопированный файл не оставляем
        }
        dst.setLastModified(src.lastModified());
    }

    // ------------------------------------------------------------ перемещение

    static void move(File src, File dstDir, Progress p) throws IOException {
        File dst = uniqueName(dstDir, src.getName());
        if (src.renameTo(dst)) return; // тот же диск: мгновенно
        copyTree(src, dst, p);
        deleteTree(src, p);
    }

    // --------------------------------------------------------------- удаление

    static void deleteTree(File f, Progress p) throws IOException {
        check(p);
        if (f.isDirectory()) {
            File[] ch = f.listFiles();
            if (ch != null) {
                for (File c : ch) deleteTree(c, p);
            }
        }
        if (p != null) p.update(f.getName());
        if (!f.delete() && f.exists()) {
            throw new IOException("Не удалось удалить: " + f.getName());
        }
    }

    // ----------------------------------------------------------------- размер

    /** Возвращает {байт, файлов, папок}. */
    static long[] sizeOf(File root, Progress p) {
        long bytes = 0;
        long files = 0;
        long dirs = 0;
        ArrayDeque<File> stack = new ArrayDeque<File>();
        stack.push(root);
        int visited = 0;
        while (!stack.isEmpty()) {
            if (p != null && p.cancelled()) break;
            File f = stack.pop();
            if (++visited > 200000) break;
            if (f.isDirectory()) {
                if (f != root) dirs++;
                File[] ch = f.listFiles();
                if (ch != null) {
                    for (File c : ch) stack.push(c);
                }
            } else {
                files++;
                bytes += f.length();
            }
            if (p != null && visited % 500 == 0) {
                p.update(Fmt.size(bytes) + "…");
            }
        }
        return new long[]{bytes, files, dirs};
    }

    // ---------------------------------------------------------------- ZIP

    /** Распаковывает архив в папку dest. Возвращает число распакованных файлов. */
    static int unzip(File zip, File dest, Progress p) throws IOException {
        ZipFile zf = openZip(zip);
        int count = 0;
        try {
            String destPath = dest.getCanonicalPath();
            if (!dest.mkdirs() && !dest.isDirectory()) {
                throw new IOException("Не удалось создать папку " + dest.getName());
            }
            Enumeration<? extends ZipEntry> en = zf.entries();
            byte[] buf = new byte[64 * 1024];
            while (en.hasMoreElements()) {
                check(p);
                ZipEntry e = en.nextElement();
                File out = new File(dest, e.getName());
                String outPath = out.getCanonicalPath();
                // защита от выхода за пределы папки назначения
                if (!outPath.equals(destPath) && !outPath.startsWith(destPath + "/")) continue;
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                if (p != null) p.update(e.getName());

                InputStream in = zf.getInputStream(e);
                OutputStream os = new FileOutputStream(out);
                boolean ok = false;
                try {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        if (p != null && p.cancelled()) throw new Cancelled();
                    }
                    ok = true;
                } finally {
                    try { in.close(); } catch (IOException ignored) { }
                    try { os.close(); } catch (IOException ignored) { }
                    if (!ok) out.delete();
                }
                if (e.getTime() > 0) out.setLastModified(e.getTime());
                count++;
            }
        } finally {
            try { zf.close(); } catch (IOException ignored) { }
        }
        return count;
    }

    // Русские имена в старых архивах бывают в кодировке CP866: определяем автоматически
    private static ZipFile openZip(File zip) throws IOException {
        ZipFile zf = new ZipFile(zip, Charset.forName("UTF-8"));
        boolean bad = false;
        Enumeration<? extends ZipEntry> en = zf.entries();
        while (en.hasMoreElements()) {
            if (en.nextElement().getName().indexOf('\uFFFD') >= 0) {
                bad = true;
                break;
            }
        }
        if (!bad) return zf;
        try { zf.close(); } catch (IOException ignored) { }
        return new ZipFile(zip, Charset.forName("IBM866"));
    }

    // ----------------------------------------------------------------- поиск

    /** Ищет файлы и папки по части имени. Не более limit результатов. */
    static List<File> search(File root, String query, int limit, Progress p) {
        List<File> out = new ArrayList<File>();
        String q = query.toLowerCase(Locale.getDefault());
        ArrayDeque<File> queue = new ArrayDeque<File>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && out.size() < limit) {
            if (p != null && p.cancelled()) break;
            File dir = queue.poll();
            File[] ch = dir.listFiles();
            if (ch == null) continue;
            if (++visited % 100 == 0 && p != null) {
                p.update("Просмотрено папок: " + visited + ", найдено: " + out.size());
            }
            for (File f : ch) {
                if (f.getName().toLowerCase(Locale.getDefault()).contains(q)) {
                    out.add(f);
                    if (out.size() >= limit) break;
                }
                if (f.isDirectory()) queue.add(f);
            }
            if (visited > 100000) break;
        }
        return out;
    }
}
