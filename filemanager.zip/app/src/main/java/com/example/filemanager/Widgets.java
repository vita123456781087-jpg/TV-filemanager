package com.example.filemanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Лёгкие самодельные виджеты: иконка файла и полоса заполнения хранилища. */
final class Widgets {

    private Widgets() { }

    /** Иконка типа файла, рисуется линиями и фигурами. Для картинок может показывать миниатюру. */
    static final class FileIcon extends View {
        private int type = Fmt.T_OTHER;
        private String ext = "";
        private Bitmap thumb;
        private boolean checked;
        private int accent = 0xFF38BDF8;

        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Path path = new Path();
        private final RectF r = new RectF();
        private final Rect src = new Rect();

        FileIcon(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        }

        void set(int type, String ext, int accent) {
            this.type = type;
            this.ext = ext == null ? "" : ext;
            this.accent = accent;
            invalidate();
        }

        void setThumb(Bitmap b) {
            if (thumb == b) return;
            thumb = b;
            invalidate();
        }

        void setChecked(boolean c) {
            if (checked == c) return;
            checked = c;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight());
            if (s <= 0) return;
            int col = Fmt.colorOf(type);

            // подложка
            fill.setColor((col & 0x00FFFFFF) | 0x33000000);
            r.set(0, 0, s, s);
            c.drawRoundRect(r, s * 0.22f, s * 0.22f, fill);

            if (thumb != null && !thumb.isRecycled()) {
                c.save();
                path.reset();
                path.addRoundRect(r, s * 0.22f, s * 0.22f, Path.Direction.CW);
                c.clipPath(path);
                int tw = thumb.getWidth();
                int th = thumb.getHeight();
                int side = Math.min(tw, th);
                src.set((tw - side) / 2, (th - side) / 2, (tw + side) / 2, (th + side) / 2);
                c.drawBitmap(thumb, src, r, bmp);
                c.restore();
            } else {
                drawGlyph(c, s, col);
            }

            if (checked) {
                float cx = s * 0.76f;
                float cy = s * 0.76f;
                fill.setColor(accent);
                c.drawCircle(cx, cy, s * 0.24f, fill);
                line.setColor(0xFFFFFFFF);
                line.setStrokeWidth(s * 0.06f);
                path.reset();
                path.moveTo(cx - s * 0.11f, cy);
                path.lineTo(cx - s * 0.02f, cy + s * 0.09f);
                path.lineTo(cx + s * 0.12f, cy - s * 0.09f);
                c.drawPath(path, line);
            }
        }

        private void page(Canvas c, float s, int col) {
            line.setColor(col);
            line.setStrokeWidth(s * 0.055f);
            r.set(s * 0.27f, s * 0.17f, s * 0.73f, s * 0.83f);
            c.drawRoundRect(r, s * 0.06f, s * 0.06f, line);
        }

        private void drawGlyph(Canvas c, float s, int col) {
            fill.setColor(col);
            line.setColor(col);
            line.setStrokeWidth(s * 0.07f);
            switch (type) {
                case Fmt.T_DIR:
                    r.set(s * 0.16f, s * 0.28f, s * 0.46f, s * 0.42f);
                    c.drawRoundRect(r, s * 0.04f, s * 0.04f, fill);
                    r.set(s * 0.16f, s * 0.36f, s * 0.84f, s * 0.76f);
                    c.drawRoundRect(r, s * 0.07f, s * 0.07f, fill);
                    break;
                case Fmt.T_VIDEO:
                    path.reset();
                    path.moveTo(s * 0.38f, s * 0.27f);
                    path.lineTo(s * 0.38f, s * 0.73f);
                    path.lineTo(s * 0.75f, s * 0.5f);
                    path.close();
                    c.drawPath(path, fill);
                    break;
                case Fmt.T_AUDIO:
                    c.drawCircle(s * 0.40f, s * 0.67f, s * 0.10f, fill);
                    c.drawLine(s * 0.49f, s * 0.67f, s * 0.49f, s * 0.27f, line);
                    c.drawLine(s * 0.49f, s * 0.27f, s * 0.72f, s * 0.36f, line);
                    break;
                case Fmt.T_IMAGE:
                    c.drawCircle(s * 0.66f, s * 0.34f, s * 0.07f, fill);
                    path.reset();
                    path.moveTo(s * 0.16f, s * 0.75f);
                    path.lineTo(s * 0.40f, s * 0.46f);
                    path.lineTo(s * 0.54f, s * 0.62f);
                    path.lineTo(s * 0.64f, s * 0.52f);
                    path.lineTo(s * 0.84f, s * 0.75f);
                    path.close();
                    c.drawPath(path, fill);
                    break;
                case Fmt.T_APK:
                    c.drawLine(s * 0.5f, s * 0.24f, s * 0.5f, s * 0.58f, line);
                    path.reset();
                    path.moveTo(s * 0.36f, s * 0.46f);
                    path.lineTo(s * 0.5f, s * 0.60f);
                    path.lineTo(s * 0.64f, s * 0.46f);
                    c.drawPath(path, line);
                    c.drawLine(s * 0.28f, s * 0.74f, s * 0.72f, s * 0.74f, line);
                    break;
                case Fmt.T_ARCHIVE:
                    page(c, s, col);
                    for (int i = 0; i < 5; i++) {
                        float x = (i % 2 == 0) ? s * 0.45f : s * 0.51f;
                        r.set(x, s * 0.20f + i * s * 0.1f, x + s * 0.06f, s * 0.20f + i * s * 0.1f + s * 0.07f);
                        c.drawRect(r, fill);
                    }
                    break;
                case Fmt.T_DOC:
                    page(c, s, col);
                    line.setStrokeWidth(s * 0.045f);
                    c.drawLine(s * 0.36f, s * 0.38f, s * 0.64f, s * 0.38f, line);
                    c.drawLine(s * 0.36f, s * 0.50f, s * 0.64f, s * 0.50f, line);
                    c.drawLine(s * 0.36f, s * 0.62f, s * 0.54f, s * 0.62f, line);
                    break;
                case Fmt.T_PDF:
                    page(c, s, col);
                    label(c, s, "PDF", col, 0.19f);
                    break;
                case Fmt.T_DRIVE:
                    line.setStrokeWidth(s * 0.06f);
                    r.set(s * 0.16f, s * 0.36f, s * 0.84f, s * 0.66f);
                    c.drawRoundRect(r, s * 0.07f, s * 0.07f, line);
                    c.drawCircle(s * 0.70f, s * 0.51f, s * 0.04f, fill);
                    c.drawLine(s * 0.26f, s * 0.51f, s * 0.46f, s * 0.51f, line);
                    break;
                default:
                    page(c, s, col);
                    if (ext.length() > 0) {
                        String e = ext.length() > 4 ? ext.substring(0, 4) : ext;
                        label(c, s, e.toUpperCase(), col, e.length() > 3 ? 0.15f : 0.18f);
                    }
                    break;
            }
        }

        private void label(Canvas c, float s, String t, int col, float size) {
            text.setColor(col);
            text.setTextSize(s * size);
            Paint.FontMetrics fm = text.getFontMetrics();
            c.drawText(t, s * 0.5f, s * 0.52f - (fm.ascent + fm.descent) / 2f, text);
        }
    }

    /** Полоса заполнения хранилища. */
    static final class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float frac = 0f;
        private int color = 0xFF38BDF8;

        Bar(Context c) {
            super(c);
        }

        void set(float fraction, int accent) {
            frac = Math.max(0f, Math.min(1f, fraction));
            // красный, когда почти заполнено
            color = frac > 0.9f ? 0xFFF87171 : (frac > 0.75f ? 0xFFFBBF24 : accent);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setColor(0x33FFFFFF);
            r.set(0, 0, w, h);
            c.drawRoundRect(r, h / 2f, h / 2f, p);
            if (frac > 0f) {
                p.setColor(color);
                r.set(0, 0, Math.max(h, w * frac), h);
                c.drawRoundRect(r, h / 2f, h / 2f, p);
            }
        }
    }
}
