package com.example.filemanager;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки файлового менеджера и список пунктов меню настроек. */
final class Cfg {

    static final String ACCENT = "accent", BG = "bg", ROWS = "rows", SORT = "sort",
            FIRST = "first", HIDDEN = "hidden", THUMBS = "thumbs", INFO = "info",
            CONFIRM = "confirm", START = "start";
    static final String LAST = "last_path";

    // верх и низ фона
    static final int[][] BGS = {
            {0xFF0B1220, 0xFF141C33}, // Ночь
            {0xFF121416, 0xFF1D2024}, // Графит
            {0xFF000000, 0xFF0A0A0A}, // Чёрный
            {0xFF06182E, 0xFF0B3358}  // Синий
    };

    // Голубой, Фиолетовый, Розовый, Оранжевый, Зелёный, Красный, Белый
    static final int[] ACCENTS = {
            0xFF38BDF8, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316, 0xFF22C55E, 0xFFEF4444, 0xFFFFFFFF
    };

    static final String[] SORT_NAMES = {
            "Имя А → Я", "Имя Я → А", "Дата: новые", "Дата: старые",
            "Размер: большие", "Размер: малые"
    };

    static final class Opt {
        final String key;
        final String title;
        final int def;
        final String[] labels;

        Opt(String key, String title, int def, String... labels) {
            this.key = key;
            this.title = title;
            this.def = def;
            this.labels = labels;
        }
    }

    static final Opt[] OPTS = {
            new Opt(ACCENT, "Акцентный цвет", 0, "Голубой", "Фиолетовый", "Розовый",
                    "Оранжевый", "Зелёный", "Красный", "Белый"),
            new Opt(BG, "Фон", 0, "Ночь", "Графит", "Чёрный", "Синий"),
            new Opt(ROWS, "Размер строк", 1, "Компактные", "Обычные", "Крупные"),
            new Opt(SORT, "Сортировка", 0, SORT_NAMES),
            new Opt(FIRST, "Папки сверху", 0, "Да", "Нет"),
            new Opt(HIDDEN, "Скрытые файлы", 0, "Скрывать", "Показывать"),
            new Opt(THUMBS, "Миниатюры картинок", 0, "Вкл", "Выкл"),
            new Opt(INFO, "Размер и дата в списке", 0, "Размер и дата", "Только размер", "Скрыть"),
            new Opt(CONFIRM, "Подтверждать удаление", 0, "Да", "Нет"),
            new Opt(START, "При запуске открывать", 0, "Главный экран", "Внутренняя память",
                    "Последнюю папку")
    };

    private final SharedPreferences sp;

    Cfg(Context c) {
        sp = c.getSharedPreferences("fm_prefs", Context.MODE_PRIVATE);
    }

    int get(String key) {
        for (Opt o : OPTS) {
            if (o.key.equals(key)) {
                return Math.max(0, Math.min(o.labels.length - 1, sp.getInt(key, o.def)));
            }
        }
        return 0;
    }

    void set(String key, int v) { sp.edit().putInt(key, v).apply(); }

    String getStr(String key) { return sp.getString(key, null); }

    void putStr(String key, String v) { sp.edit().putString(key, v).apply(); }
}
