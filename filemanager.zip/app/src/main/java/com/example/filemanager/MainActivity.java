package com.example.filemanager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int DLG = android.R.style.Theme_Material_Dialog_Alert;
    private static final int REQ_PERM = 1;
    private static final float[] ROW_UNITS = {5.4f, 6.4f, 7.6f};

    // ----------------------------------------------------------- модели

    private static final class Item {
        File f;
        String name;
        boolean dir;
        long size;
        long mod;
        int type;
        String ext;
        String sizeStr;
        String dateStr;
    }

    private static final class Root {
        String title;
        String sub;
        File dir;
        float used = -1f;
        boolean usb;
    }

    private interface Body {
        String run(Ops.Progress p) throws Exception;
    }

    // ---------------------------------------------------------- состояние

    private Cfg cfg;
    private float u;
    private int accent = Cfg.ACCENTS[0];
    private int rowPx;
    private boolean thumbsOn = true;
    private boolean hiddenOn = false;
    private int infoMode = 0;

    private FrameLayout root;
    private LinearLayout header;
    private View accentLine;
    private TextView pathTv;
    private TextView infoTv;
    private TextView hintTv;
    private TextView emptyTv;
    private ListView list;
    private ScrollView homeScroll;
    private GridLayout homeGrid;
    private FileAdapter adapter;
    private FrameLayout settingsOverlay;

    private int mode = 0;          // 0 главный экран, 1 папка, 2 результаты поиска
    private File cur;              // текущая папка (в режиме поиска: где искали)
    private final List<Item> items = new ArrayList<Item>();
    private boolean loadError = false;
    private long loadToken = 0;

    private boolean selMode = false;
    private final Set<String> selected = new HashSet<String>();
    private final List<File> clip = new ArrayList<File>();
    private boolean clipCut = false;
    private boolean longFired = false;

    private LruCache<String, Bitmap> thumbCache;
    private ExecutorService thumbExec;
    private final Set<String> pending = new HashSet<String>();

    private final BroadcastReceiver mountReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { onStorageChanged(); }
    };

    // ================================================================ старт

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new Cfg(this);
        u = getResources().getDisplayMetrics().widthPixels / 100f;
        // Разрешает передавать файлы другим приложениям по пути (открытие, установка APK)
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());

        thumbCache = new LruCache<String, Bitmap>(3 * 1024 * 1024) {
            @Override protected int sizeOf(String k, Bitmap bmp) { return bmp.getByteCount(); }
        };
        thumbExec = Executors.newSingleThreadExecutor();

        readSettings();
        buildUi();
        applyTheme();

        if (Build.VERSION.SDK_INT >= 23 && !hasStoragePermission()) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
        } else {
            startUp();
        }
    }

    private boolean hasStoragePermission() {
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_PERM) return;
        if (!hasStoragePermission()) {
            toast("Без доступа к файлам менеджер работать не сможет. Разрешите в настройках приложения.");
        }
        startUp();
    }

    private void startUp() {
        int s = cfg.get(Cfg.START);
        if (s == 1) {
            showDir(Environment.getExternalStorageDirectory(), null);
        } else if (s == 2) {
            String last = cfg.getStr(Cfg.LAST);
            File f = last == null ? null : new File(last);
            if (f != null && f.isDirectory()) showDir(f, null);
            else showHome();
        } else {
            showHome();
        }
    }

    private int px(float units) { return Math.round(units * u); }

    private TextView text(String s, float sizeU, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private static String plural(int n, String one, String few, String many) {
        int m100 = n % 100;
        int m10 = n % 10;
        if (m100 >= 11 && m100 <= 14) return n + " " + many;
        if (m10 == 1) return n + " " + one;
        if (m10 >= 2 && m10 <= 4) return n + " " + few;
        return n + " " + many;
    }

    private void readSettings() {
        accent = Cfg.ACCENTS[cfg.get(Cfg.ACCENT)];
        rowPx = px(ROW_UNITS[cfg.get(Cfg.ROWS)]);
        thumbsOn = cfg.get(Cfg.THUMBS) == 0;
        hiddenOn = cfg.get(Cfg.HIDDEN) == 1;
        infoMode = cfg.get(Cfg.INFO);
    }

    // =================================================================== вид

    private void buildUi() {
        root = new FrameLayout(this);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);

        header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(px(4f), px(2.6f), px(4f), px(1f));
        pathTv = text("", 2.8f, Color.WHITE);
        pathTv.setSingleLine(true);
        pathTv.setEllipsize(TextUtils.TruncateAt.START);
        infoTv = text("", 1.5f, 0x99FFFFFF);
        infoTv.setSingleLine(true);
        header.addView(pathTv);
        header.addView(infoTv);
        main.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        accentLine = new View(this);
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(2, px(0.25f)));
        al.leftMargin = px(4f);
        al.rightMargin = px(4f);
        main.addView(accentLine, al);

        FrameLayout content = new FrameLayout(this);

        adapter = new FileAdapter();
        list = new ListView(this);
        list.setDivider(null);
        list.setVerticalScrollBarEnabled(false);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list.setPadding(px(3f), px(0.6f), px(3f), px(0.6f));
        list.setClipToPadding(false);
        list.setFocusable(true);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < items.size()) activate(items.get(pos));
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            if (pos < items.size()) showItemMenu(items.get(pos));
            return true;
        });
        content.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        homeScroll = new ScrollView(this);
        homeScroll.setVerticalScrollBarEnabled(false);
        homeScroll.setClipToPadding(false);
        homeScroll.setPadding(px(4.3f), px(1f), px(4.3f), px(2f));
        homeGrid = new GridLayout(this);
        homeGrid.setColumnCount(3);
        homeScroll.addView(homeGrid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(homeScroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyTv = text("", 2.4f, 0x88FFFFFF);
        emptyTv.setGravity(Gravity.CENTER);
        emptyTv.setVisibility(View.GONE);
        content.addView(emptyTv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        main.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        hintTv = text("", 1.4f, 0x77FFFFFF);
        hintTv.setSingleLine(true);
        hintTv.setPadding(px(4f), px(0.8f), px(4f), px(1.2f));
        main.addView(hintTv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(main, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void applyTheme() {
        int[] bg = Cfg.BGS[cfg.get(Cfg.BG)];
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{bg[0], bg[1]}));
        accentLine.setBackgroundColor((accent & 0x00FFFFFF) | 0x88000000);

        GradientDrawable sel = new GradientDrawable();
        sel.setColor((accent & 0x00FFFFFF) | 0x33000000);
        sel.setCornerRadius(1.0f * u);
        sel.setStroke(Math.max(2, Math.round(0.22f * u)), accent);
        list.setSelector(sel);

        adapter.notifyDataSetChanged();
        if (mode == 0 && homeGrid != null && homeGrid.getChildCount() > 0) buildHome();
    }

    // ======================================================== хранилища

    private static boolean sameDir(File a, File b) {
        try {
            return a.getCanonicalPath().equals(b.getCanonicalPath());
        } catch (IOException e) {
            return a.getPath().equals(b.getPath());
        }
    }

    private Root makeRoot(String title, File dir, boolean usb, boolean stats) {
        Root r = new Root();
        r.title = title;
        r.dir = dir;
        r.usb = usb;
        r.sub = dir.getPath();
        if (stats) {
            try {
                StatFs s = new StatFs(dir.getPath());
                long total = s.getTotalBytes();
                long free = s.getAvailableBytes();
                if (total > 0) {
                    r.used = (float) (total - free) / total;
                    r.sub = "Свободно " + Fmt.size(free) + " из " + Fmt.size(total);
                }
            } catch (Exception ignored) { }
        }
        return r;
    }

    private List<Root> roots(boolean stats) {
        List<Root> out = new ArrayList<Root>();
        File internal = Environment.getExternalStorageDirectory();
        out.add(makeRoot("Внутренняя память", internal, false, stats));

        File[] vols = new File("/storage").listFiles();
        int n = 0;
        if (vols != null) {
            for (File v : vols) {
                String nm = v.getName();
                if (nm.equals("self") || nm.equals("emulated")) continue;
                if (!v.isDirectory() || v.list() == null) continue;
                if (sameDir(v, internal)) continue;
                n++;
            }
            int k = 0;
            for (File v : vols) {
                String nm = v.getName();
                if (nm.equals("self") || nm.equals("emulated")) continue;
                if (!v.isDirectory() || v.list() == null) continue;
                if (sameDir(v, internal)) continue;
                k++;
                out.add(makeRoot(n > 1 ? "USB-накопитель " + k : "USB-накопитель", v, true, stats));
            }
        }
        Root sys = makeRoot("Системный корень", new File("/"), false, false);
        sys.sub = "Корневая папка устройства";
        out.add(sys);
        return out;
    }

    private boolean isRootDir(File f) {
        if (f.getParentFile() == null) return true;
        for (Root r : roots(false)) {
            if (sameDir(r.dir, f)) return true;
        }
        return false;
    }

    // Путь вида «Внутренняя память › Download › Фильмы»
    private String crumb(File f) {
        String p = f.getPath();
        Root sys = null;
        for (Root r : roots(false)) {
            String rp = r.dir.getPath();
            if (rp.equals("/")) { sys = r; continue; }
            if (p.equals(rp)) return r.title;
            if (p.startsWith(rp + "/")) {
                return r.title + "  ›  " + p.substring(rp.length() + 1).replace("/", "  ›  ");
            }
        }
        if (p.equals("/")) return sys != null ? sys.title : "/";
        return "Системный корень  ›  " + p.substring(1).replace("/", "  ›  ");
    }

    // ===================================================== главный экран

    private void showHome() {
        mode = 0;
        cur = null;
        loadToken++;
        clearSel(false);
        list.setVisibility(View.GONE);
        emptyTv.setVisibility(View.GONE);
        homeScroll.setVisibility(View.VISIBLE);
        pathTv.setText("Файловый менеджер");
        buildHome();
        updateInfo();
        updateHint();
    }

    private void buildHome() {
        homeGrid.removeAllViews();
        addGridTitle("ХРАНИЛИЩА");
        for (final Root r : roots(true)) {
            final File d = r.dir;
            addCard(r.title, r.sub, Fmt.T_DRIVE, r.used, () -> showDir(d, null));
        }

        String[] dirs = {Environment.DIRECTORY_DOWNLOADS, Environment.DIRECTORY_MOVIES,
                Environment.DIRECTORY_MUSIC, Environment.DIRECTORY_PICTURES,
                Environment.DIRECTORY_DCIM};
        String[] names = {"Загрузки", "Фильмы", "Музыка", "Изображения", "Камера"};
        boolean titled = false;
        for (int i = 0; i < dirs.length; i++) {
            final File d = Environment.getExternalStoragePublicDirectory(dirs[i]);
            if (d == null || !d.isDirectory()) continue;
            if (!titled) {
                addGridTitle("БЫСТРЫЙ ДОСТУП");
                titled = true;
            }
            addCard(names[i], "Папка", Fmt.T_DIR, -1f, () -> showDir(d, null));
        }
        homeGrid.post(new Runnable() {
            @Override public void run() {
                for (int i = 0; i < homeGrid.getChildCount(); i++) {
                    View c = homeGrid.getChildAt(i);
                    if (c.isFocusable() && mode == 0 && settingsOverlay == null) {
                        c.requestFocus();
                        break;
                    }
                }
            }
        });
    }

    private void addGridTitle(String s) {
        TextView t = text(s, 1.4f, accent);
        t.setPadding(px(0.7f), px(1.4f), 0, px(0.4f));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(0, 3));
        homeGrid.addView(t, lp);
    }

    private Drawable cardBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor((accent & 0x00FFFFFF) | 0x33000000);
        on.setCornerRadius(1.2f * u);
        on.setStroke(Math.max(2, Math.round(0.25f * u)), accent);
        GradientDrawable off = new GradientDrawable();
        off.setColor(0x16FFFFFF);
        off.setCornerRadius(1.2f * u);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, off);
        return sl;
    }

    private void addCard(String title, String sub, int type, float used, final Runnable action) {
        FrameLayout card = new FrameLayout(this);
        card.setFocusable(true);
        card.setClickable(true);
        card.setBackground(cardBg());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(px(1.4f), px(1.2f), px(1.4f), px(1.2f));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        int is = px(5.2f);
        Widgets.FileIcon ic = new Widgets.FileIcon(this);
        ic.set(type, "", accent);
        top.addView(ic, new LinearLayout.LayoutParams(is, is));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = text(title, 2.1f, Color.WHITE);
        t1.setSingleLine(true);
        t1.setEllipsize(TextUtils.TruncateAt.END);
        TextView t2 = text(sub, 1.3f, 0x99FFFFFF);
        t2.setSingleLine(true);
        t2.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        tx.addView(t1);
        tx.addView(t2);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.leftMargin = px(1.2f);
        top.addView(tx, tp);
        col.addView(top);

        if (used >= 0f) {
            Widgets.Bar bar = new Widgets.Bar(this);
            bar.set(used, accent);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Math.max(4, px(0.7f)));
            bp.topMargin = px(1.2f);
            col.addView(bar, bp);
        }
        card.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL));
        card.setOnClickListener(v -> action.run());

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = px(28.5f);
        lp.height = px(11.5f);
        lp.setMargins(px(0.7f), px(0.5f), px(0.7f), px(0.5f));
        homeGrid.addView(card, lp);
    }

    // ============================================================== папки

    private void showDir(File dir, String selectName) {
        mode = 1;
        cur = dir;
        clearSel(false);
        homeScroll.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
        pathTv.setText(crumb(dir));
        cfg.putStr(Cfg.LAST, dir.getPath());
        load(dir, selectName);
    }

    private void reload() {
        if (mode == 1 && cur != null) load(cur, selectedName());
        else if (mode == 2) adapter.notifyDataSetChanged();
    }

    private String selectedName() {
        int pos = list.getSelectedItemPosition();
        if (pos >= 0 && pos < items.size()) return items.get(pos).name;
        return null;
    }

    private Item makeItem(File f) {
        Item it = new Item();
        it.f = f;
        it.name = f.getName();
        it.dir = f.isDirectory();
        it.size = it.dir ? 0 : f.length();
        it.mod = f.lastModified();
        it.type = Fmt.typeOf(it.name, it.dir);
        it.ext = Fmt.ext(it.name);
        it.sizeStr = it.dir ? "" : Fmt.size(it.size);
        it.dateStr = it.mod > 0 ? Fmt.date(it.mod) : "";
        return it;
    }

    private static void sortItems(List<Item> l, final int sort, final boolean foldersFirst) {
        Collections.sort(l, new Comparator<Item>() {
            @Override public int compare(Item a, Item b) {
                if (foldersFirst && a.dir != b.dir) return a.dir ? -1 : 1;
                int r;
                switch (sort) {
                    case 1: r = b.name.compareToIgnoreCase(a.name); break;
                    case 2: r = Long.compare(b.mod, a.mod); break;
                    case 3: r = Long.compare(a.mod, b.mod); break;
                    case 4: r = Long.compare(b.size, a.size); break;
                    case 5: r = Long.compare(a.size, b.size); break;
                    default: r = a.name.compareToIgnoreCase(b.name); break;
                }
                if (r == 0) r = a.name.compareToIgnoreCase(b.name);
                return r;
            }
        });
    }

    // Содержимое папки читается в фоне, чтобы интерфейс не замирал на медленной флешке
    private void load(final File dir, final String selectName) {
        final long token = ++loadToken;
        items.clear();
        adapter.notifyDataSetChanged();
        emptyTv.setVisibility(View.GONE);
        infoTv.setText("Загрузка…");

        final boolean showHidden = hiddenOn;
        final int sort = cfg.get(Cfg.SORT);
        final boolean foldersFirst = cfg.get(Cfg.FIRST) == 0;

        new Thread(new Runnable() {
            @Override public void run() {
                File[] fs = dir.listFiles();
                final boolean err = fs == null;
                final List<Item> res = new ArrayList<Item>();
                if (fs != null) {
                    for (File f : fs) {
                        if (!showHidden && f.getName().startsWith(".")) continue;
                        res.add(makeItem(f));
                    }
                    sortItems(res, sort, foldersFirst);
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (token != loadToken) return;
                        items.addAll(res);
                        loadError = err;
                        finishLoad(selectName);
                    }
                });
            }
        }).start();
    }

    private void finishLoad(String selectName) {
        adapter.notifyDataSetChanged();
        boolean empty = items.isEmpty();
        emptyTv.setText(loadError ? "Нет доступа к папке"
                : (mode == 2 ? "Ничего не найдено" : "Папка пуста"));
        emptyTv.setVisibility(empty ? View.VISIBLE : View.GONE);

        int idx = 0;
        if (selectName != null) {
            for (int i = 0; i < items.size(); i++) {
                if (items.get(i).name.equals(selectName)) {
                    idx = i;
                    break;
                }
            }
        }
        final int sel = idx;
        list.post(new Runnable() {
            @Override public void run() {
                if (!items.isEmpty()) list.setSelection(sel);
                if (settingsOverlay == null) list.requestFocus();
            }
        });
        updateInfo();
        updateHint();
    }

    private void updateInfo() {
        StringBuilder sb = new StringBuilder();
        if (mode == 0) {
            sb.append("Выберите хранилище или папку");
        } else if (selMode) {
            sb.append("Выбрано: ").append(selected.size()).append(" из ").append(items.size());
        } else {
            int d = 0;
            int f = 0;
            long bytes = 0;
            for (Item it : items) {
                if (it.dir) d++;
                else {
                    f++;
                    bytes += it.size;
                }
            }
            sb.append(plural(d, "папка", "папки", "папок")).append("  ·  ")
              .append(plural(f, "файл", "файла", "файлов")).append("  ·  ").append(Fmt.size(bytes));
        }
        if (!clip.isEmpty()) {
            sb.append("     Буфер: ").append(plural(clip.size(), "элемент", "элемента", "элементов"))
              .append(clipCut ? " (вырезано)" : " (копия)");
        }
        infoTv.setText(sb.toString());
    }

    private void updateHint() {
        String s;
        if (settingsOverlay != null) {
            s = "← → меняют значение   ·   OK — следующее   ·   Назад — закрыть";
        } else if (mode == 0) {
            s = "OK — открыть   ·   Menu — настройки";
        } else if (selMode) {
            s = "OK — отметить   ·   Menu — действия   ·   Назад — отмена выбора";
        } else {
            s = "OK — открыть   ·   удерживайте OK — меню файла   ·   Menu — действия   ·   Назад — вверх";
        }
        hintTv.setText(s);
    }

    // ============================================================ список

    private static final class Holder {
        Widgets.FileIcon icon;
        TextView name;
        TextView sub;
        TextView size;
        TextView date;
    }

    private View newRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), 0, px(1.4f), 0);
        r.setLayoutParams(new AbsListView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, rowPx));

        Holder h = new Holder();
        int is = Math.round(rowPx * 0.76f);
        h.icon = new Widgets.FileIcon(this);
        r.addView(h.icon, new LinearLayout.LayoutParams(is, is));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        h.name = text("", 2.0f, Color.WHITE);
        h.name.setSingleLine(true);
        h.name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        h.sub = text("", 1.3f, 0x88FFFFFF);
        h.sub.setSingleLine(true);
        h.sub.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        col.addView(h.name);
        col.addView(h.sub);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        cp.leftMargin = px(1.4f);
        r.addView(col, cp);

        h.size = text("", 1.7f, 0xBBFFFFFF);
        h.size.setGravity(Gravity.END);
        h.size.setSingleLine(true);
        r.addView(h.size, new LinearLayout.LayoutParams(px(11f),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        h.date = text("", 1.5f, 0x88FFFFFF);
        h.date.setGravity(Gravity.END);
        h.date.setSingleLine(true);
        r.addView(h.date, new LinearLayout.LayoutParams(px(15f),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        r.setTag(h);
        return r;
    }

    private final class FileAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) v = newRow();
            Holder h = (Holder) v.getTag();
            Item it = items.get(pos);
            String path = it.f.getPath();
            boolean sel = selected.contains(path);

            h.icon.set(it.type, it.ext, accent);
            h.icon.setChecked(sel);
            Bitmap tb = null;
            if (thumbsOn && it.type == Fmt.T_IMAGE) {
                h.icon.setTag(path);
                tb = thumbCache.get(path);
                if (tb == null) requestThumb(path);
            } else {
                h.icon.setTag(null);
            }
            h.icon.setThumb(tb);

            h.name.setText(it.name);
            if (mode == 2) {
                h.sub.setText(it.f.getParent());
                h.sub.setVisibility(View.VISIBLE);
            } else {
                h.sub.setVisibility(View.GONE);
            }
            h.size.setVisibility(infoMode <= 1 ? View.VISIBLE : View.GONE);
            h.size.setText(it.sizeStr);
            h.date.setVisibility(infoMode == 0 ? View.VISIBLE : View.GONE);
            h.date.setText(it.dateStr);
            v.setBackgroundColor(sel ? ((accent & 0x00FFFFFF) | 0x22000000) : Color.TRANSPARENT);
            return v;
        }
    }

    // ------------------------------------------------------------ миниатюры

    private static Bitmap decodeThumb(String path) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= 128 && o.outHeight / (sample * 2) >= 128) {
                sample *= 2;
            }
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(path, o);
        } catch (Throwable t) {
            return null;
        }
    }

    // Миниатюры грузятся по одной в фоне; после загрузки обновляются только видимые строки
    private void requestThumb(final String path) {
        if (!pending.add(path)) return;
        thumbExec.execute(new Runnable() {
            @Override public void run() {
                final Bitmap b = decodeThumb(path);
                if (b != null) thumbCache.put(path, b);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        pending.remove(path);
                        if (b == null || isFinishing()) return;
                        int first = list.getFirstVisiblePosition();
                        int last = list.getLastVisiblePosition();
                        for (int i = first; i <= last && i < items.size(); i++) {
                            if (i >= 0 && items.get(i).f.getPath().equals(path)) {
                                adapter.notifyDataSetChanged();
                                break;
                            }
                        }
                    }
                });
            }
        });
    }

    // ============================================================ открытие

    private void activate(Item it) {
        if (selMode) {
            toggleSel(it);
        } else if (it.dir) {
            showDir(it.f, null);
        } else if (it.ext.equals("zip")) {
            showItemMenu(it);
        } else {
            openFile(it.f);
        }
    }

    private void openFile(File f) {
        String ext = Fmt.ext(f.getName());
        String mime = ext.equals("apk") ? "application/vnd.android.package-archive"
                : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        if (mime == null) mime = "*/*";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.fromFile(f), mime);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Нет приложения для открытия этого файла");
        }
    }

    // ============================================================ выделение

    private void toggleSel(Item it) {
        String p = it.f.getPath();
        if (!selected.remove(p)) selected.add(p);
        adapter.notifyDataSetChanged();
        updateInfo();
    }

    private void clearSel(boolean refresh) {
        boolean was = selMode || !selected.isEmpty();
        selMode = false;
        selected.clear();
        if (refresh && was) {
            adapter.notifyDataSetChanged();
            updateInfo();
            updateHint();
        }
    }

    private List<File> selectedFiles() {
        List<File> out = new ArrayList<File>();
        for (Item it : items) {
            if (selected.contains(it.f.getPath())) out.add(it.f);
        }
        return out;
    }

    private void enterSelMode() {
        selMode = true;
        adapter.notifyDataSetChanged();
        updateInfo();
        updateHint();
    }

    // =============================================================== меню

    private void showMenu(String title, List<String> names, final List<Runnable> acts) {
        new AlertDialog.Builder(this, DLG)
                .setTitle(title)
                .setItems(names.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void confirm(String msg, final Runnable yes) {
        new AlertDialog.Builder(this, DLG)
                .setMessage(msg)
                .setPositiveButton("Да", (d, w) -> yes.run())
                .setNegativeButton("Отмена", null)
                .show();
    }

    // Меню файла (удержание OK)
    private void showItemMenu(final Item it) {
        if (selMode) {
            showSelMenu();
            return;
        }
        final List<String> n = new ArrayList<String>();
        final List<Runnable> a = new ArrayList<Runnable>();

        if (it.dir) {
            n.add("Открыть");
            a.add(() -> showDir(it.f, null));
        } else if (it.type == Fmt.T_APK) {
            n.add("Установить");
            a.add(() -> openFile(it.f));
        } else {
            n.add("Открыть");
            a.add(() -> openFile(it.f));
        }
        if (it.ext.equals("zip")) {
            n.add("Распаковать в папку «" + baseName(it.name) + "»");
            a.add(() -> unzip(it.f, true));
            n.add("Распаковать сюда");
            a.add(() -> unzip(it.f, false));
        }
        n.add("Выбрать");
        a.add(() -> {
            enterSelMode();
            toggleSel(it);
        });
        n.add("Копировать");
        a.add(() -> setClip(Arrays.asList(it.f), false));
        n.add("Вырезать");
        a.add(() -> setClip(Arrays.asList(it.f), true));
        n.add("Переименовать");
        a.add(() -> rename(it));
        n.add("Удалить");
        a.add(() -> deleteFiles(Arrays.asList(it.f)));
        n.add("Свойства");
        a.add(() -> props(it));
        showMenu(it.name, n, a);
    }

    private static String baseName(String name) {
        int d = name.lastIndexOf('.');
        return d > 0 ? name.substring(0, d) : name;
    }

    // Меню действий с отмеченными файлами
    private void showSelMenu() {
        final List<String> n = new ArrayList<String>();
        final List<Runnable> a = new ArrayList<Runnable>();
        n.add("Копировать");
        a.add(() -> {
            if (selected.isEmpty()) toast("Ничего не выбрано");
            else setClip(selectedFiles(), false);
        });
        n.add("Вырезать");
        a.add(() -> {
            if (selected.isEmpty()) toast("Ничего не выбрано");
            else setClip(selectedFiles(), true);
        });
        n.add("Удалить");
        a.add(() -> {
            if (selected.isEmpty()) toast("Ничего не выбрано");
            else deleteFiles(selectedFiles());
        });
        n.add("Выбрать всё");
        a.add(() -> {
            for (Item it : items) selected.add(it.f.getPath());
            adapter.notifyDataSetChanged();
            updateInfo();
        });
        n.add("Снять выделение");
        a.add(() -> {
            selected.clear();
            adapter.notifyDataSetChanged();
            updateInfo();
        });
        n.add("Выйти из режима выбора");
        a.add(() -> clearSel(true));
        showMenu("Выбрано: " + selected.size(), n, a);
    }

    // Общее меню (кнопка Menu)
    private void openMenu() {
        if (settingsOverlay != null) return;
        if (selMode) {
            showSelMenu();
            return;
        }
        final List<String> n = new ArrayList<String>();
        final List<Runnable> a = new ArrayList<Runnable>();

        if (mode == 1) {
            if (!clip.isEmpty()) {
                n.add("Вставить сюда (" + clip.size() + ")");
                a.add(() -> paste());
            }
            n.add("Новая папка");
            a.add(() -> newFolder());
            n.add("Поиск");
            a.add(() -> searchDialog());
            n.add("Выбрать несколько");
            a.add(() -> enterSelMode());
            n.add("Сортировка…");
            a.add(() -> showSortMenu());
            n.add(hiddenOn ? "Скрыть скрытые файлы" : "Показать скрытые файлы");
            a.add(() -> toggleHidden());
            n.add("Обновить");
            a.add(() -> reload());
            n.add("Все хранилища");
            a.add(() -> showHome());
        } else if (mode == 2) {
            n.add("Закрыть поиск");
            a.add(() -> showDir(cur, null));
            n.add("Все хранилища");
            a.add(() -> showHome());
        } else {
            n.add("Обновить");
            a.add(() -> buildHome());
        }
        n.add("Настройки");
        a.add(() -> openSettings());
        showMenu("Меню", n, a);
    }

    private void showSortMenu() {
        new AlertDialog.Builder(this, DLG)
                .setTitle("Сортировка")
                .setSingleChoiceItems(Cfg.SORT_NAMES, cfg.get(Cfg.SORT), (d, which) -> {
                    cfg.set(Cfg.SORT, which);
                    d.dismiss();
                    reload();
                })
                .show();
    }

    private void cycleSort() {
        if (mode != 1) return;
        int next = (cfg.get(Cfg.SORT) + 1) % Cfg.SORT_NAMES.length;
        cfg.set(Cfg.SORT, next);
        toast("Сортировка: " + Cfg.SORT_NAMES[next]);
        reload();
    }

    private void toggleHidden() {
        if (mode == 0) return;
        cfg.set(Cfg.HIDDEN, hiddenOn ? 0 : 1);
        readSettings();
        toast(hiddenOn ? "Скрытые файлы показаны" : "Скрытые файлы скрыты");
        reload();
    }

    // ======================================================= операции

    private void setClip(List<File> fs, boolean cut) {
        clip.clear();
        clip.addAll(fs);
        clipCut = cut;
        clearSel(true);
        updateInfo();
        toast((cut ? "Вырезано: " : "Скопировано: ") + fs.size()
                + ". Откройте нужную папку: Menu → Вставить");
    }

    private void paste() {
        if (clip.isEmpty() || mode != 1 || cur == null) return;
        final File dest = cur;
        final List<File> src = new ArrayList<File>(clip);
        final boolean cut = clipCut;
        runJob(cut ? "Перемещение" : "Копирование", p -> {
            int n = 0;
            for (File f : src) {
                if (p.cancelled()) throw new Ops.Cancelled();
                if (f.isDirectory() && Ops.isInside(f, dest)) {
                    throw new IOException("Нельзя вставить папку в саму себя: " + f.getName());
                }
                if (cut && dest.equals(f.getParentFile())) continue; // уже здесь
                if (cut) Ops.move(f, dest, p);
                else Ops.copy(f, dest, p);
                n++;
            }
            return (cut ? "Перемещено: " : "Скопировано: ") + n;
        }, () -> {
            if (cut) clip.clear();
            updateInfo();
            reload();
        });
    }

    private void deleteFiles(final List<File> fs) {
        if (fs.isEmpty()) return;
        final Runnable go = () -> runJob("Удаление", p -> {
            int n = 0;
            for (File f : fs) {
                Ops.deleteTree(f, p);
                n++;
            }
            return "Удалено: " + n;
        }, () -> {
            clearSel(false);
            reload();
        });
        if (cfg.get(Cfg.CONFIRM) == 0) {
            String what = fs.size() == 1 ? "«" + fs.get(0).getName() + "»"
                    : plural(fs.size(), "элемент", "элемента", "элементов");
            confirm("Удалить " + what + "? Это нельзя отменить.", go);
        } else {
            go.run();
        }
    }

    private EditText input(String initial, String hint) {
        EditText et = new EditText(this);
        et.setText(initial);
        et.setHint(hint);
        et.setSingleLine(true);
        et.setSelectAllOnFocus(true);
        et.setTextColor(Color.WHITE);
        et.setHintTextColor(0x66FFFFFF);
        return et;
    }

    private FrameLayout padded(View v) {
        FrameLayout fl = new FrameLayout(this);
        fl.setPadding(px(2f), px(1f), px(2f), 0);
        fl.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return fl;
    }

    private void rename(final Item it) {
        final EditText et = input(it.name, "Новое имя");
        new AlertDialog.Builder(this, DLG)
                .setTitle("Переименовать")
                .setView(padded(et))
                .setPositiveButton("OK", (d, w) -> {
                    String nn = et.getText().toString().trim();
                    if (nn.isEmpty() || nn.contains("/")) {
                        toast("Недопустимое имя");
                        return;
                    }
                    File t = new File(it.f.getParentFile(), nn);
                    if (t.exists()) {
                        toast("Такое имя уже есть");
                    } else if (it.f.renameTo(t)) {
                        toast("Переименовано");
                        if (mode == 1) load(cur, nn);
                    } else {
                        toast("Не удалось переименовать");
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void newFolder() {
        if (mode != 1 || cur == null) return;
        final EditText et = input("Новая папка", "Имя папки");
        new AlertDialog.Builder(this, DLG)
                .setTitle("Новая папка")
                .setView(padded(et))
                .setPositiveButton("Создать", (d, w) -> {
                    String nn = et.getText().toString().trim();
                    if (nn.isEmpty() || nn.contains("/")) {
                        toast("Недопустимое имя");
                        return;
                    }
                    File t = new File(cur, nn);
                    if (t.exists()) toast("Такая папка уже есть");
                    else if (t.mkdir()) load(cur, nn);
                    else toast("Не удалось создать папку");
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void searchDialog() {
        if (mode != 1 || cur == null) return;
        final File base = cur;
        final EditText et = input("", "Часть имени файла");
        new AlertDialog.Builder(this, DLG)
                .setTitle("Поиск в папке «" + base.getName() + "»")
                .setView(padded(et))
                .setPositiveButton("Искать", (d, w) -> {
                    final String q = et.getText().toString().trim();
                    if (q.isEmpty()) return;
                    final List<File> found = new ArrayList<File>();
                    runJob("Поиск", p -> {
                        found.addAll(Ops.search(base, q, 500, p));
                        return "Найдено: " + found.size();
                    }, () -> showResults(q, found));
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void showResults(String q, List<File> found) {
        mode = 2;
        clearSel(false);
        homeScroll.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
        pathTv.setText("Поиск: «" + q + "»");
        List<Item> res = new ArrayList<Item>();
        for (File f : found) res.add(makeItem(f));
        sortItems(res, 0, true);
        items.clear();
        items.addAll(res);
        loadError = false;
        loadToken++;
        finishLoad(null);
    }

    private void unzip(final File zip, final boolean intoFolder) {
        if (cur == null) return;
        final File dest = intoFolder ? Ops.uniqueName(cur, baseName(zip.getName())) : cur;
        runJob("Распаковка", p -> "Распаковано файлов: " + Ops.unzip(zip, dest, p), () -> {
            if (mode == 1) load(cur, intoFolder ? dest.getName() : null);
        });
    }

    private void props(final Item it) {
        final String head = "Имя: " + it.name
                + "\nПуть: " + it.f.getParent()
                + "\nТип: " + Fmt.typeName(it.type)
                + "\nИзменён: " + it.dateStr
                + "\nДоступ: " + (it.f.canRead() ? "чтение" : "") + (it.f.canWrite() ? ", запись" : "");
        final TextView tv = text(head + "\nРазмер: считаю…", 1.8f, Color.WHITE);
        tv.setPadding(px(2f), px(1f), px(2f), 0);
        final boolean[] cancel = {false};
        AlertDialog dlg = new AlertDialog.Builder(this, DLG)
                .setTitle("Свойства")
                .setView(tv)
                .setPositiveButton("Закрыть", null)
                .create();
        dlg.setOnDismissListener(d -> cancel[0] = true);
        dlg.show();
        new Thread(new Runnable() {
            @Override public void run() {
                final long[] s = it.dir ? Ops.sizeOf(it.f, new Ops.Progress() {
                    @Override public void update(String m) { }
                    @Override public boolean cancelled() { return cancel[0]; }
                }) : new long[]{it.size, 1, 0};
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        String t = head + "\nРазмер: " + Fmt.size(s[0]) + " (" + s[0] + " байт)";
                        if (it.dir) {
                            t += "\nВнутри: " + plural((int) s[2], "папка", "папки", "папок")
                                    + ", " + plural((int) s[1], "файл", "файла", "файлов");
                        }
                        tv.setText(t);
                    }
                });
            }
        }).start();
    }

    // Выполняет долгую операцию в фоне с окном прогресса и кнопкой «Отмена»
    private void runJob(String title, final Body body, final Runnable after) {
        final boolean[] cancel = {false};
        final long[] last = {0};
        final TextView msg = text("…", 1.8f, Color.WHITE);
        msg.setPadding(px(2f), px(1f), px(2f), 0);
        final AlertDialog dlg = new AlertDialog.Builder(this, DLG)
                .setTitle(title)
                .setView(msg)
                .setCancelable(false)
                .setNegativeButton("Отмена", null)
                .create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            cancel[0] = true;
            msg.setText("Отмена…");
        });

        new Thread(new Runnable() {
            @Override public void run() {
                String result;
                try {
                    result = body.run(new Ops.Progress() {
                        @Override public void update(final String m) {
                            long now = System.nanoTime();
                            if (now - last[0] < 100000000L) return; // не чаще 10 раз в секунду
                            last[0] = now;
                            runOnUiThread(new Runnable() {
                                @Override public void run() { msg.setText(m); }
                            });
                        }
                        @Override public boolean cancelled() { return cancel[0]; }
                    });
                } catch (Ops.Cancelled c) {
                    result = "Отменено";
                } catch (Throwable t) {
                    result = "Ошибка: " + (t.getMessage() == null ? t.toString() : t.getMessage());
                }
                final String r = result;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try { dlg.dismiss(); } catch (Exception ignored) { }
                        toast(r);
                        if (after != null) after.run();
                    }
                });
            }
        }).start();
    }

    // ============================================================ настройки

    private Drawable rowBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(0x33FFFFFF);
        on.setCornerRadius(0.8f * u);
        on.setStroke(Math.max(2, Math.round(0.2f * u)), accent);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return sl;
    }

    private void openSettings() {
        if (settingsOverlay != null) return;
        settingsOverlay = new FrameLayout(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xF2101624);
        panel.setPadding(px(2f), px(2.5f), px(1.5f), px(1f));
        panel.addView(text("Настройки", 3f, Color.WHITE));
        panel.addView(text("Пульт: красная — поиск, зелёная — новая папка, "
                + "жёлтая — сортировка, синяя — скрытые файлы", 1.2f, 0x77FFFFFF));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setPadding(0, px(1f), px(0.5f), px(2f));
        sv.setClipToPadding(false);
        LinearLayout lst = new LinearLayout(this);
        lst.setOrientation(LinearLayout.VERTICAL);

        View first = null;
        for (Cfg.Opt o : Cfg.OPTS) {
            View r = optRow(o);
            if (first == null) first = r;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = px(0.3f);
            lst.addView(r, lp);
        }
        sv.addView(lst, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        settingsOverlay.addView(panel, new FrameLayout.LayoutParams(
                px(40f), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));
        root.addView(settingsOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        list.setFocusable(false);
        homeScroll.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        updateHint();
        if (first != null) first.requestFocus();
    }

    private void closeSettings() {
        if (settingsOverlay == null) return;
        root.removeView(settingsOverlay);
        settingsOverlay = null;
        list.setFocusable(true);
        homeScroll.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        updateHint();
        if (mode == 0) buildHome();
        else list.requestFocus();
    }

    private View optRow(final Cfg.Opt o) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));

        r.addView(text(o.title, 1.8f, Color.WHITE),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text("", 1.8f, accent);
        r.addView(val);
        setValueText(val, o);

        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> changeOpt(o, val, 1));
        r.setOnKeyListener((x, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) { changeOpt(o, val, 1); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { changeOpt(o, val, -1); return true; }
            return false;
        });
        return r;
    }

    private void setValueText(TextView val, Cfg.Opt o) {
        val.setText("‹ " + o.labels[cfg.get(o.key)] + " ›");
    }

    private void changeOpt(Cfg.Opt o, TextView val, int dir) {
        int n = o.labels.length;
        int next = (cfg.get(o.key) + dir + n) % n;
        cfg.set(o.key, next);
        setValueText(val, o);
        readSettings();
        switch (o.key) {
            case Cfg.ACCENT:
            case Cfg.BG:
                applyTheme();
                break;
            case Cfg.ROWS:
                list.setAdapter(adapter); // строки пересоздаются с новой высотой
                break;
            case Cfg.SORT:
            case Cfg.FIRST:
            case Cfg.HIDDEN:
                reload();
                break;
            default:
                adapter.notifyDataSetChanged();
                break;
        }
    }

    // ===================================================== клавиши пульта

    private boolean listActive() {
        return mode != 0 && settingsOverlay == null && list.getVisibility() == View.VISIBLE;
    }

    private void handleSpecial(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_MENU:
                openMenu();
                break;
            case KeyEvent.KEYCODE_PROG_RED:
                searchDialog();
                break;
            case KeyEvent.KEYCODE_PROG_GREEN:
                newFolder();
                break;
            case KeyEvent.KEYCODE_PROG_YELLOW:
                cycleSort();
                break;
            case KeyEvent.KEYCODE_PROG_BLUE:
                toggleHidden();
                break;
            default:
                break;
        }
    }

    // OK открывает файл, удержание OK открывает меню файла
    private void handleCenter(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) {
                longFired = false;
            } else if (e.getRepeatCount() == 1 && !longFired) {
                longFired = true;
                int pos = list.getSelectedItemPosition();
                if (pos >= 0 && pos < items.size()) showItemMenu(items.get(pos));
            }
        } else if (e.getAction() == KeyEvent.ACTION_UP) {
            if (!longFired) {
                int pos = list.getSelectedItemPosition();
                if (pos >= 0 && pos < items.size()) activate(items.get(pos));
            }
            longFired = false;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        switch (code) {
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_PROG_RED:
            case KeyEvent.KEYCODE_PROG_GREEN:
            case KeyEvent.KEYCODE_PROG_YELLOW:
            case KeyEvent.KEYCODE_PROG_BLUE:
                if (e.getAction() == KeyEvent.ACTION_UP) handleSpecial(code);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (listActive()) {
                    handleCenter(e);
                    return true;
                }
                break;
            default:
                break;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onBackPressed() {
        if (settingsOverlay != null) {
            closeSettings();
        } else if (selMode) {
            clearSel(true);
        } else if (mode == 2) {
            showDir(cur, null);
        } else if (mode == 1) {
            File parent = cur.getParentFile();
            if (isRootDir(cur) || parent == null) showHome();
            else showDir(parent, cur.getName()); // выбрана папка, из которой вышли
        } else {
            finish();
        }
    }

    // =========================================================== USB и диски

    private void onStorageChanged() {
        if (mode == 0) {
            buildHome();
        } else if (cur != null && !cur.exists()) {
            toast("Накопитель отключён");
            showHome();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_MEDIA_MOUNTED);
        f.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        f.addAction(Intent.ACTION_MEDIA_REMOVED);
        f.addAction(Intent.ACTION_MEDIA_EJECT);
        f.addAction(Intent.ACTION_MEDIA_BAD_REMOVAL);
        f.addDataScheme("file");
        registerReceiver(mountReceiver, f);
    }

    @Override
    protected void onStop() {
        super.onStop();
        try { unregisterReceiver(mountReceiver); } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        thumbExec.shutdownNow();
    }
}
