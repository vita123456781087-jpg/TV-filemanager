package com.example.filemanager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Типы файлов, цвета, форматирование размера и даты. */
final class Fmt {

    static final int T_DIR = 0;
    static final int T_VIDEO = 1;
    static final int T_AUDIO = 2;
    static final int T_IMAGE = 3;
    static final int T_APK = 4;
    static final int T_ARCHIVE = 5;
    static final int T_DOC = 6;
    static final int T_PDF = 7;
    static final int T_OTHER = 8;
    static final int T_DRIVE = 9;

    private static final String VIDEO =
            " mp4 mkv avi mov wmv flv webm ts m4v mpg mpeg 3gp m2ts vob ";
    private static final String AUDIO =
            " mp3 flac wav ogg m4a aac wma opus ape alac ";
    private static final String IMAGE =
            " jpg jpeg png gif bmp webp heic ";
    private static final String ARCHIVE =
            " zip rar 7z tar gz tgz bz2 xz iso ";
    private static final String DOC =
            " txt log md json xml html htm csv ini conf srt sub ass ssa m3u m3u8 nfo ";

    private Fmt() { }

    static String ext(String name) {
        int d = name.lastIndexOf('.');
        if (d > 0 && d < name.length() - 1) return name.substring(d + 1).toLowerCase(Locale.ROOT);
        return "";
    }

    static int typeOf(String name, boolean dir) {
        if (dir) return T_DIR;
        String e = ext(name);
        if (e.isEmpty()) return T_OTHER;
        String k = " " + e + " ";
        if (VIDEO.contains(k)) return T_VIDEO;
        if (AUDIO.contains(k)) return T_AUDIO;
        if (IMAGE.contains(k)) return T_IMAGE;
        if (e.equals("apk")) return T_APK;
        if (ARCHIVE.contains(k)) return T_ARCHIVE;
        if (e.equals("pdf")) return T_PDF;
        if (DOC.contains(k)) return T_DOC;
        return T_OTHER;
    }

    static int colorOf(int type) {
        switch (type) {
            case T_DIR: return 0xFFF5B942;
            case T_VIDEO: return 0xFF8B5CF6;
            case T_AUDIO: return 0xFFEC4899;
            case T_IMAGE: return 0xFF22C55E;
            case T_APK: return 0xFF3DDC84;
            case T_ARCHIVE: return 0xFFF97316;
            case T_DOC: return 0xFF60A5FA;
            case T_PDF: return 0xFFEF4444;
            case T_DRIVE: return 0xFF38BDF8;
            default: return 0xFF94A3B8;
        }
    }

    static String typeName(int type) {
        switch (type) {
            case T_DIR: return "Папка";
            case T_VIDEO: return "Видео";
            case T_AUDIO: return "Аудио";
            case T_IMAGE: return "Изображение";
            case T_APK: return "Приложение (APK)";
            case T_ARCHIVE: return "Архив";
            case T_DOC: return "Текстовый файл";
            case T_PDF: return "Документ PDF";
            default: return "Файл";
        }
    }

    static String size(long b) {
        if (b < 1024) return b + " Б";
        double kb = b / 1024.0;
        if (kb < 1024) return Math.round(kb) + " КБ";
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.getDefault(), "%.1f МБ", mb);
        return String.format(Locale.getDefault(), "%.2f ГБ", mb / 1024.0);
    }

    private static final SimpleDateFormat DF =
            new SimpleDateFormat("dd.MM.yy  HH:mm", Locale.getDefault());

    static synchronized String date(long ms) {
        return DF.format(new Date(ms));
    }
}
